package com.xpto.config;
// ... (conteúdo conforme já gerado anteriormente)

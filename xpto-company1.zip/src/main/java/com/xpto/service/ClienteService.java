package com.xpto.service;
// ... (conteúdo conforme já gerado anteriormente)

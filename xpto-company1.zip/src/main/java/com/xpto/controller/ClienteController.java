package com.xpto.controller;
// ... (conteúdo conforme já gerado anteriormente)
